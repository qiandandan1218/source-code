%%
%===============================pre_data================================
clear all
load('TH_NpHR_1_D6_pre.mat')
for i=1:4:29
    eval(['data_pre.FP',num2str(i,'%02d'),'=TETFP',num2str(i,'%02d'),';']);
    eval(['data_pre.FP',num2str(i+1,'%02d'),'=TETFP',num2str(i,'%02d'),'_1;']);
    eval(['data_pre.FP',num2str(i+2,'%02d'),'=TETFP',num2str(i,'%02d'),'_2;']);
    eval(['data_pre.FP',num2str(i+3,'%02d'),'=TETFP',num2str(i,'%02d'),'_3;']);
end
clearvars -except data_pre

fmin=12;
fmax=25;
%filter params
passband=[fmin,fmax];
order = 4;
nyquist = 500;
if passband(1) == 0
    filt_order = round(order*2*nyquist./passband(2));    
	[params.b, params.a] = fir1(filt_order,passband(2)/nyquist,'low');
    elseif passband(2) == inf
        filt_order = round(order*2*nyquist./passband(1));    
		[params.b, params.a] = fir1(filt_order,passband(1)/nyquist,'high');
    else
        filt_order = round(order*2*nyquist./passband(1));  
		[params.b, params.a] = fir1(filt_order,passband/nyquist);
end
clear passband order nyquist

for i=1:32
    eval(['fil_channel_data=FiltFiltM(params.b,params.a,double(data_pre.FP',num2str(i,'%02d'),'));']);
    hilb_channel_data(:,i) = abs(hilbert(fil_channel_data));
    tr(1,i)=mean(hilb_channel_data(601:1000,i));
    subplot(2,1,1);eval(['plot(data_pre.FP',num2str(i,'%02d'),');']);
    subplot(2,1,2);plot(fil_channel_data);hold on;plot(hilb_channel_data(:,i),'r');
    mean_beta=mean(hilb_channel_data(:,i));
    std_beta=mean(hilb_channel_data(:,i));
    plot([0 length(fil_channel_data)],[mean_beta mean_beta],'k');
    plot([0 length(fil_channel_data)],[mean_beta+3*std_beta mean_beta+3*std_beta],'--');
    saveas(gcf,[cd, '\result\pre\no ',num2str(i),'.fig']);  
    close all
end

%%
%===============================stim_data================================
close all
load('TH_NpHR_1_D6_stim.mat')
for i=1:4:29
    eval(['data_stim.FP',num2str(i,'%02d'),'=TETFP',num2str(i,'%02d'),';']);
    eval(['data_stim.FP',num2str(i+1,'%02d'),'=TETFP',num2str(i,'%02d'),'_1;']);
    eval(['data_stim.FP',num2str(i+2,'%02d'),'=TETFP',num2str(i,'%02d'),'_2;']);
    eval(['data_stim.FP',num2str(i+3,'%02d'),'=TETFP',num2str(i,'%02d'),'_3;']);
end
clearvars -except data_stim data_pre mean_beta std_beta


fmin=15;
fmax=30;
%filter params
passband=[fmin,fmax];
order = 4;
nyquist = 500;
if passband(1) == 0
    filt_order = round(order*2*nyquist./passband(2));    
	[params.b, params.a] = fir1(filt_order,passband(2)/nyquist,'low');
    elseif passband(2) == inf
        filt_order = round(order*2*nyquist./passband(1));    
		[params.b, params.a] = fir1(filt_order,passband(1)/nyquist,'high');
    else
        filt_order = round(order*2*nyquist./passband(1));  
		[params.b, params.a] = fir1(filt_order,passband/nyquist);
end
clear passband order nyquist

for i=1:32
    eval(['fil_channel_data=FiltFiltM(params.b,params.a,double(data_stim.FP',num2str(i,'%02d'),'));']);
    hilb_channel_data(:,i) = abs(hilbert(fil_channel_data));
    tr(1,i)=mean(hilb_channel_data(601:1000,i));
    subplot(2,1,1);eval(['plot(data_stim.FP',num2str(i,'%02d'),');']);
    subplot(2,1,2);plot(fil_channel_data);hold on;plot(hilb_channel_data(:,i),'r');
    plot([0 length(fil_channel_data)],[mean_beta mean_beta],'k');
    plot([0 length(fil_channel_data)],[mean_beta+3*std_beta mean_beta+3*std_beta],'--');
    saveas(gcf,[cd, '\result\stim\no ',num2str(i),'.jpg']);  
    close all
end

