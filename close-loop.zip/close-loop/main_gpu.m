%%
%***************************************************************************************************
fmin=12;
fmax=30;
thr=mean_beta+3*std_beta;
p=8;

%%
%connect to omniplex
s = PL_InitClient(0);
if s == 0
   return
end
% basic parameters
pars = PL_GetPars(s);
fprintf_pars( pars );
% % PlexDO initialization - must be called before any other PlexDO function.
[numDOCards, deviceNumbers, numBits, numLines]=PL_DOGetDigitalOutputInfo;
% Get the names of the available digital output devices (optional).
for i = 1:numDOCards
    [result, deviceString] = PL_DOGetDeviceString(deviceNumbers(i)); %#ok<*ASGLU>
    % str = sprintf('NI Device %d = %s\n', deviceNumbers(i), deviceString);
end
% Initialize the first available device.  The second parameter should be 1 
% if the device is also being used by the MAP, otherwise 0.
result = PL_DOInitDevice(deviceNumbers(1), 0);%#ok<*NASGU,*ASGLU>
% Set all output bits to 0.
result = PL_DOClearAllBits(deviceNumbers(1));

%%
%filter parameters setting
params.Fs=1000;
%first reciever to test fast_fs or low_fs
fast_fs=pars(13);low_fs=pars(8);
[~, ~, ~] = PL_GetAD(s);pause(2);[n, ~, ~] = PL_GetAD(s);
if n<10000
    params.real_fs=low_fs;
else
    params.real_fs=fast_fs;
end
clear fast_fs low_fs n

%initialization
Register=zeros(params.real_fs,32);
channel_data=zeros(params.Fs*1,32);
hilb_channel_data=zeros(params.Fs*1,32);
tr=zeros(1,32);
state=0;


clear Record
count_max=100000;
Record.state=cell(count_max,1);
count=1;
Record.timestamps=cell(count_max,1);
Record.data=cell(count_max,1);


%filter params
passband=[fmin,fmax];
order = 4;
nyquist = 500;
if passband(1) == 0
    filt_order = round(order*2*nyquist./passband(2));    
	[params.b, params.a] = fir1(filt_order,passband(2)/nyquist,'low');
    elseif passband(2) == inf
        filt_order = round(order*2*nyquist./passband(1));    
		[params.b, params.a] = fir1(filt_order,passband(1)/nyquist,'high');
    else
        filt_order = round(order*2*nyquist./passband(1));  
		[params.b, params.a] = fir1(filt_order,passband/nyquist);
end
clear passband order nyquist
%%
%Start!!first reciever
[~, ~, ~] = PL_GetAD(s);
pause(1);
[n, tstart, d] = PL_GetAD(s);
tend=tstart+(n-1)/params.real_fs;
temp=([Register;d(:,1:32)]);
temp(1:(length(temp)-params.real_fs),:)=[];
Register=temp;
clear temp d
Record.Start=tend;
% get A/D data
while(count<count_max)
   tic
   [n, tstart, d] = PL_GetAD(s);   
   tend=tstart+(n-1)/params.real_fs;   
   temp=([Register;d(:,1:32)]);
   temp(1:(length(temp)-params.real_fs),:)=[];
   Register=temp;
   clear temp
   
   Record.timestamps{count,1}=[tstart tend];
   Record.data{count,1}=d(:,1:32);
   Record.state{count,1}=state;
   
   for i=1:32
        if(params.real_fs==40000) 
            channel_data(:,i)=mean(reshape(Register(:,i),40,1000),1);
        else
            channel_data(:,i)=Register(:,i);
        end
   end
   fil_channel_data = FiltFiltM(params.b,params.a,double(channel_data));
   for i=1:32
        hilb_channel_data(:,i) = abs(hilbert(fil_channel_data(:,i)));
        tr(1,i)=mean(hilb_channel_data(601:1000,i));
   end
   %***************************************************************************************
   flag=0;
   if (sum((tr>thr)))>=p
       flag=1;
   end
   if(flag==1)&&(state==0)
      PL_DOSetBit(deviceNumbers(1), 1); % open
      state=1;
   end
   if(flag==0)&&(state==1)
      PL_DOClearBit(deviceNumbers(1), 1); % close
      state=0;
   end
   count=count+1;
   
   
   t=toc; 
   while abs(t-0.02)>1e-5
        t=toc;
        if(t>0.03)
            break;
        end
   end
   toc
end
%%
% you need to call PL_Close(s) to close the connection
% with the Plexon server
PL_DOReleaseDevices();
PL_Close(s);
s = 0;
save();