%%
%===============================pre_data================================
clear all
load('TH_NpHR_1_D6_pre.mat')
for i=1:4:29
    eval(['data_pre.FP',num2str(i,'%02d'),'=TETFP',num2str(i,'%02d'),';']);
    eval(['data_pre.FP',num2str(i+1,'%02d'),'=TETFP',num2str(i,'%02d'),'_1;']);
    eval(['data_pre.FP',num2str(i+2,'%02d'),'=TETFP',num2str(i,'%02d'),'_2;']);
    eval(['data_pre.FP',num2str(i+3,'%02d'),'=TETFP',num2str(i,'%02d'),'_3;']);
end
clearvars -except data_pre

fmin=15;
fmax=30;
%filter params
passband=[fmin,fmax];
order = 4;
nyquist = 500;
if passband(1) == 0
    filt_order = round(order*2*nyquist./passband(2));    
	[params.b, params.a] = fir1(filt_order,passband(2)/nyquist,'low');
    elseif passband(2) == inf
        filt_order = round(order*2*nyquist./passband(1));    
		[params.b, params.a] = fir1(filt_order,passband(1)/nyquist,'high');
    else
        filt_order = round(order*2*nyquist./passband(1));  
		[params.b, params.a] = fir1(filt_order,passband/nyquist);
end
clear passband order nyquist

for i=1:32
    eval(['fil_channel_data=FiltFiltM(params.b,params.a,double(data_pre.FP',num2str(i,'%02d'),'));']);
    hilb_channel_data(:,i) = abs(hilbert(fil_channel_data));
    subplot(2,1,1);eval(['plot(data_pre.FP',num2str(i,'%02d'),');']);
    subplot(2,1,2);plot(fil_channel_data);hold on;plot(hilb_channel_data(:,i),'r');
    mean_beta=mean(hilb_channel_data(:,i));
    std_beta=std(hilb_channel_data(:,i));
    close all
end

%%
%===============================stim_data================================
close all
load('TH_NpHR_1_D6_stim.mat')
for i=1:4:29
    eval(['data_stim_FP(:,',num2str(i,'%02d'),')=TETFP',num2str(i,'%02d'),';']);
    eval(['data_stim_FP(:,',num2str(i+1,'%02d'),')=TETFP',num2str(i,'%02d'),'_1;']);
    eval(['data_stim_FP(:,',num2str(i+2,'%02d'),')=TETFP',num2str(i,'%02d'),'_2;']);
    eval(['data_stim_FP(:,',num2str(i+3,'%02d'),')=TETFP',num2str(i,'%02d'),'_3;']);
end
clearvars -except data_stim_FP data_pre mean_beta std_beta

%parameter

thr=mean_beta+3*std_beta;
p=8;
fmin=15;
fmax=30;
%filter params
passband=[fmin,fmax];
order = 4;
nyquist = 500;
if passband(1) == 0
    filt_order = round(order*2*nyquist./passband(2));    
	[params.b, params.a] = fir1(filt_order,passband(2)/nyquist,'low');
    elseif passband(2) == inf
        filt_order = round(order*2*nyquist./passband(1));    
		[params.b, params.a] = fir1(filt_order,passband(1)/nyquist,'high');
    else
        filt_order = round(order*2*nyquist./passband(1));  
		[params.b, params.a] = fir1(filt_order,passband/nyquist);
end
clear passband order nyquist

%initialization
params.real_fs=1000;
params.Fs=1000;
channel_data=zeros(params.Fs*1,32);
hilb_channel_data=zeros(params.Fs*1,32);
tr=zeros(1,32);
state=0;
clear Record

count=1;
%Start!!first reciever
Register=data_stim_FP(1:1000,1:32);
tend=1000;
% get A/D data
while(tend<=(60000-20))
   tic
   d=data_stim_FP((tend+1):(tend+20),1:32);
   tend=(tend+20);
   temp=([Register;d(:,1:32)]);
   temp(1:(length(temp)-params.real_fs),:)=[];
   Register=temp;
   clear temp
   
   for i=1:32
        channel_data(:,i)=Register(:,i);
   end
   fil_channel_data = FiltFiltM(params.b,params.a,double(channel_data));
   for i=1:32
        hilb_channel_data(:,i) = abs(hilbert(fil_channel_data(:,i)));
        tr(1,i)=mean(hilb_channel_data(601:1000,i));
   end
   %***************************************************************************************
   state_record((tend-19):(tend),1)=state;
   flag=0;
   if (sum((tr>thr)))>=p
       flag=1;
   end
   if(flag==1)&&(state==0)
      %PL_DOSetBit(deviceNumbers(1), 1); % open
      state=1;
   end
   if(flag==0)&&(state==1)
      %PL_DOClearBit(deviceNumbers(1), 1); % close
      state=0;
   end
   state_record((tend-19):(tend),2)=state;
   count=count+1;
   t=toc; 
   while abs(t-0.02)>1e-5
        t=toc;
        if(t>0.03)
            break;
        end
   end
   toc
end



%%
%output
close all
load('TH_NpHR_1_D6_stim.mat')
for i=1:4:29
    eval(['data_stim.FP',num2str(i,'%02d'),'=TETFP',num2str(i,'%02d'),';']);
    eval(['data_stim.FP',num2str(i+1,'%02d'),'=TETFP',num2str(i,'%02d'),'_1;']);
    eval(['data_stim.FP',num2str(i+2,'%02d'),'=TETFP',num2str(i,'%02d'),'_2;']);
    eval(['data_stim.FP',num2str(i+3,'%02d'),'=TETFP',num2str(i,'%02d'),'_3;']);
end
clearvars -except data_stim data_pre mean_beta std_beta state_record


fmin=15;
fmax=30;
%filter params
passband=[fmin,fmax];
order = 4;
nyquist = 500;
if passband(1) == 0
    filt_order = round(order*2*nyquist./passband(2));    
	[params.b, params.a] = fir1(filt_order,passband(2)/nyquist,'low');
    elseif passband(2) == inf
        filt_order = round(order*2*nyquist./passband(1));    
		[params.b, params.a] = fir1(filt_order,passband(1)/nyquist,'high');
    else
        filt_order = round(order*2*nyquist./passband(1));  
		[params.b, params.a] = fir1(filt_order,passband/nyquist);
end
clear passband order nyquist

for i=1:32
    eval(['fil_channel_data=FiltFiltM(params.b,params.a,double(data_stim.FP',num2str(i,'%02d'),'));']);
    hilb_channel_data(:,i) = abs(hilbert(fil_channel_data));
    tr(1,i)=mean(hilb_channel_data(601:1000,i));
    subplot(2,1,1);eval(['plot(data_stim.FP',num2str(i,'%02d'),');']);
    subplot(2,1,2);plot(fil_channel_data);hold on;plot(hilb_channel_data(:,i),'r');hold on;
    plot([0 length(fil_channel_data)],[mean_beta mean_beta],'k');hold on;
    plot([0 length(fil_channel_data)],[mean_beta+3*std_beta mean_beta+3*std_beta],'--');hold on;
    plot(state_record(:,2),'g'); 
    set(gcf,'position',[0,0,1500,3000]);
    saveas(gcf,[cd, '\result\all\no ',num2str(i),'.jpg']); 
    close all
end

